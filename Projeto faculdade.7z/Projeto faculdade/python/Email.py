
import re
import tkinter as tk
from customtkinter import *
from PIL import Image, ImageTk
#tela
app = CTk()
app.geometry("600x400")
app.title("Email Validator")
app.resizable(False, False)

#imagem
img = Image.open("imagens\logo.png")  
imagem_redimensionada = img.resize((300, 400))   
imgtk = ImageTk.PhotoImage(imagem_redimensionada)
label_imagem = tk.Label(app, image=imgtk)
label_imagem.pack()
label_imagem.place(x=130, y=-2, anchor=N)

#botoes
btn = CTkButton(master=app, text="login",fg_color="#483D8B",width=270, height=35)
btn.place(relx=0.7, rely=0.8, anchor=S)

#labels
label1 = CTkLabel (master=app, text="Entre com seu endereço de email.", text_color="white", font=("",13))
label1.place(relx=0.7, rely=0.2,x = -35, y=-0, anchor=N)
label2 = CTkLabel (master=app, text="Bem vindo de volta!", text_color="#483D8B", font=("",30))
label2.place(relx=0.7, rely=0.1, anchor=N)

#textbox
entry1 = CTkEntry(master=app, width=270, height=35, placeholder_text="Senha", text_color="white")
entry1.place(relx=0.7, rely=0.5, anchor=N, y=10)
entry2 = CTkEntry(master=app, width=270, height=35, placeholder_text="Email", text_color="white")
entry2.place(relx=0.7, rely=0.3,y =15 , anchor=N)

#login_regex
def login():
    email = entry2.get()
    senha = entry1.get()
    pattern = "[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.(com|gov|net)"
    pattern2 = "[a-zA-Z0-9_.+-]+[a-zA-Z0-9-]"
    if re.search(pattern, email):
        print ("Email válido")
    else:
        print ("Email inválido")
        
    if re.search(pattern2, senha):
        print ("Senha válida")
    else:
        print ("Senha inválida")

#keyboard\click
btn._clicked = True
btn.configure(command=login)

def on_key(event):
    if event.keysym == "Return":
        login()
app.bind("<Return>", on_key)


app.mainloop()