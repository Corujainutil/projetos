  
  function converterData() {
    const input = document.getElementById('dataInput').value.trim();
    let resultado = "";

    const formatoAmericano = /^(\d{4})-(\d{2})-(\d{2})$/; 
    const formatoBrasileiro = /^(\d{2})\/(\d{2})\/(\d{4})$/;Y

    if (formatoAmericano.test(input)) {
      const convertido = input.replace(formatoAmericano, '$3/$2/$1');
      resultado = "Formato brasileiro: " + convertido;
    } else if (formatoBrasileiro.test(input)) {
      const convertido = input.replace(formatoBrasileiro, '$3-$2-$1');
      resultado = "Formato americano: " + convertido;
    } else {
      resultado = "Formato de data inválido!";
    }

    document.getElementById('resultado').textContent = resultado;
  }